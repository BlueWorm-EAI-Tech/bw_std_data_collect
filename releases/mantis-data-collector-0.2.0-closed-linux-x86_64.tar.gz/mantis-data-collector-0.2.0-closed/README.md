# Mantis 数据采集程序包（闭源二进制）

版本 **0.2.0-closed**。仅含 Nuitka 编译的 `.so` 与薄 shell 入口，**不含 Python 源码**；不捆绑 lerobot / ROS 2。

## 包含内容

- 数据采集前检查；
- 三路相机启动、停止、状态检查和本地查看；
- 交互式示教数据采集（单进程多集，LeRobot **v3.0**）；
- 单个或批量 LeRobot 数据检查；
- 旧数据说明信息修复工具；
- 机位 YAML 示例（`config/robot.yaml` 等）。

## 不包含内容

- 任何 `.py` 源码；
- ACT / OpenPI 推理客户端与 Web GUI；
- 数据集、模型检查点、训练结果和运行日志；
- 现场密码、密钥、服务器地址；
- ROS 2、LeRobot、相机驱动和机器人控制系统本身（见 `REQUIREMENTS.host.txt`）。

## 适用环境

- Ubuntu 22.04；x86_64；ROS 2 Humble；**Python 3.10**（ABI：`cpython-310-x86_64-linux-gnu`）；
- `lerobot>=0.4.4,<0.5`（`CODEBASE_VERSION=v3.0`）；
- 已安装与现场机器人匹配的 BlueWorm ROS 接口。

## 第一次使用前

1. 复制配置：`cp config/robot.yaml config/my-robot.yaml`，填写 namespace、相机串号、数据目录。
2. 按需修改 `config/mantis_data.env`。
3. `./bin/mantis-data doctor`
4. `./bin/mantis-data collect --config config/my-robot.yaml --state-only --task "Pick and place the cube."`

按键：`i` 开始一集，`o` 写入数据集，`d` 丢缓冲，`q` 结束并 `finalize()`。

## 常用命令

```bash
./bin/mantis-data doctor
./bin/mantis-data preflight --state-only
./bin/mantis-data collect --config config/robot.yaml --state-only --task "Pick and place the cube."
./bin/mantis-data dataset /path/to/dataset --expect-state-only --for-training
```

自解压安装：

```bash
./mantis-data-collector-0.2.0-closed-linux-x86_64.run --target "$HOME/mantis-data-collector"
```

维护组：具身组  
版本：0.2.0-closed
